<?php namespace Backend\Classes;

use Backend\Classes\DashReport;

/**
 * @deprecated use Dashboard\Classes\ReportWidgetBase
 */
abstract class ReportWidgetBase extends \Dashboard\Classes\ReportWidgetBase
{
}
