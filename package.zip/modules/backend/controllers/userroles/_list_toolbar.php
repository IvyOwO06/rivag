<div data-control="toolbar">
    <a href="<?= Backend::url('backend/userroles/create') ?>" class="btn btn-primary oc-icon-plus">
        <?= e(trans('backend::lang.user.role.new')) ?>
    </a>
</div>
