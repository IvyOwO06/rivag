<!-- Time -->
<div class="input-with-icon right-align">
    <i class="icon icon-clock"></i>
    <input
        type="text"
        id="<?= $this->getId('time') ?>"
        class="form-control align-right"
        autocomplete="off"
        <?= $field->getAttributes() ?>
        data-timepicker />
</div>
