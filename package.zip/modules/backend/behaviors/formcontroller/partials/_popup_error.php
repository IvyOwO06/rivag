<div class="modal-body">
    <p class="flash-message static error"><?= e($fatalError) ?></p>
</div>
<div class="modal-footer">
    <?= Ui::button(__("Close"))->dismissPopup() ?>
</div>
